﻿Imports System.Data.SqlClient
Imports System.Configuration

Public Class WebForm1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim Connection As SqlConnection
        Dim command As SqlCommand

        Connection = New SqlConnection(ConfigurationManager.ConnectionStrings("dbConnection").ConnectionString)

        Dim reader As SqlDataReader

        Try
            Connection.Open()
            Dim query As String
            query = "Select name from test.dbo.users where id=1"
            command = New SqlCommand(query, Connection)
            reader = command.ExecuteReader
            While reader.Read
                Dim sname As String
                sname = reader.GetValue(0)
                Response.Write(sname)
            End While
            Connection.Close()
        Catch ex As SqlException
            MsgBox(ex.Message)
        Finally
            Connection.Dispose()
        End Try

    End Sub

End Class